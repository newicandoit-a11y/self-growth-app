import React from 'react';

export default function App() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: 20 }}>
      <h1>자기성장 기록 앱</h1>
      <p>이 프로젝트는 React + Vite로 구성된 기본 구조입니다.</p>
      <p>GitHub 업로드 후 Vercel에서 Deploy를 누르면 바로 실행됩니다 🚀</p>
    </div>
  );
}
